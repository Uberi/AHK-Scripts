Standalone Scintilla DLL with AutoHotkey lexer support
------------------------------------------------------

From SciTE4AutoHotkey v3.0.05.01 - Based on Scintilla 3.4.1
AutoHotkey v1 Lexer originally written by PhiLho:
   http://www.autohotkey.com/board/topic/8813-/
AutoHotkey v2 Lexer written by fincs for SciTE4AutoHotkey:
   http://fincs.ahk4.net/scite4ahk/pages/ahkv2.htm

Reference
---------

   ; AHK v1 lexer styles
   SCLEX_AHK1 = 200
   SCE_AHK_DEFAULT      =  0  ; Default (everything not below: spaces, untyped parameters)
   SCE_AHK_COMMENTLINE  =  1  ; Line comment (; syntax)
   SCE_AHK_COMMENTBLOCK =  2  ; Block comment (/*...*/ syntax)
   SCE_AHK_ESCAPE       =  3  ; Escaped characters (`x)
   SCE_AHK_SYNOPERATOR  =  4  ; Operator
   SCE_AHK_EXPOPERATOR  =  5  ; Expression assignement operator
   SCE_AHK_STRING       =  6  ; String
   SCE_AHK_NUMBER       =  7  ; Number
   SCE_AHK_IDENTIFIER   =  8  ; Identifier (variable & function call) - Not used by the lexer but by the style below and by hotkeys
   SCE_AHK_VARREF       =  9  ; Variable dereferencing %varName%
   SCE_AHK_LABEL        = 10  ; Label & Hotstrings. Also defines a bit of style for hotkeys.
   SCE_AHK_WORD_CF      = 11  ; Keyword - Flow of control
   SCE_AHK_WORD_CMD     = 12  ; Keyword - Commands
   SCE_AHK_WORD_FN      = 13  ; Keyword - Functions
   SCE_AHK_WORD_DIR     = 14  ; Keyword - Directives
   SCE_AHK_WORD_KB      = 15  ; Keyword - Keys & buttons
   SCE_AHK_WORD_VAR     = 16  ; Keyword - Built-in Variables
   SCE_AHK_WORD_SP      = 17  ; Keyword - special parameters ("Keywords")
   SCE_AHK_WORD_UD      = 18  ; Keyword - User defined
   SCE_AHK_VARREFKW     = 19  ; Variable keyword (built-in) dereferencing %A_xxx%
   SCE_AHK_ERROR        = 20  ; Error (unclosed string, unknown operator, invalid dereferencing, etc.)

   ; AHK v1 keyword lists:
   ;
   ; keywords:  Flow of control
   ; keywords2: Commands
   ; keywords3: Functions
   ; keywords4: Directives
   ; keywords5: Keys and buttons
   ; keywords6: Variables
   ; keywords7: Keywords

   ; AHK v2 lexer styles
   SCLEX_AHK2 = 201
   SCE_AHK2_DEFAULT      =  0  ; Default style
   SCE_AHK2_COMMENTLINE  =  1  ; Line comment (; syntax)
   SCE_AHK2_COMMENTBLOCK =  2  ; Block comment (/*...*/ syntax)
   SCE_AHK2_ESCAPE       =  3  ; Escaped characters (`x)
   SCE_AHK2_OPERATOR     =  4  ; Operator
   SCE_AHK2_STRING       =  5  ; String
   SCE_AHK2_NUMBER       =  6  ; Number
   SCE_AHK2_WORDOP       =  7  ; Word operator
   SCE_AHK2_VAR          =  8  ; Variable/Identifier
   SCE_AHK2_FUNC         =  9  ; Function
   SCE_AHK2_DIRECTIVE    = 10  ; Directive
   SCE_AHK2_LABEL        = 11  ; Label/Hotkey
   SCE_AHK2_FLOW         = 12  ; Flow of Control
   SCE_AHK2_BIV          = 13  ; Built-in Variable
   SCE_AHK2_BIF          = 14  ; Built-in Function
   SCE_AHK2_ERROR        = 15  ; Syntax error

   ; AHK v2 keyword lists:
   ;
   ; keywords:  Built-in Functions
   ; keywords2: Built-in Variables
   ; keywords3: Flow of Control
   ; keywords4: Word Operators
   ; keywords5: Keys and Buttons (used for hotkey detection)
