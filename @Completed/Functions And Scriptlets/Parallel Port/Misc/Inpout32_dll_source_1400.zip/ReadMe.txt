InpOut32Drv Driver Interface DLL

Modified for x64 compatibility and built by Phillip Gibbons (Phil@Highrez.co.uk)