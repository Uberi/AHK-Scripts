========================
|                      |
|  ComDispatch() v1.0  |
|                      |
| by fincs             |
|                      |
========================

This StdLib library allows you to let COM users call AutoHotkey functions. It's a complete
rewrite of Lexikos' DispatchObj() function (http://www.autohotkey.com/forum/topic27405.html).

Changelog:

version 1.0
    - Initial release.

1. How to Integrate the library in your Project
-----------------------------------------------

This is a StdLib library, merge the contents of this Lib folder with either your local StdLib
folder (path-to-your-script\Lib), the user StdLib folder (My Documents\AutoHotkey\Lib) or the
global StdLib folder (path-to-AutoHotkey.exe\Lib). Don't #include, please.

2. Usage
--------

You can RTFM by opening the enclosed docu.chm file. There are also examples.

3. Warnings
-----------

- This library depends on Lexikos' ComVar() function. It is distributed alongst the library itself.
- This library requires AutoHotkey_L (perhaps too late to say it?)

4. TODO
-------

- Support properties.
- Automatically generate a DispTable from an object base.
