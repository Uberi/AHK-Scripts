--[[ Block
comment ]]
function first()
   -- Comment
   func(SCI_ANNOTATIONSETTEXT, 'a', 0, "LINE1")
end
