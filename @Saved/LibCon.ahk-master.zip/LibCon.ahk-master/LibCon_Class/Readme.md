Will be fork of LibCon and AHK-Console-Class.

https://github.com/joedf/LibCon.ahk  
  
https://github.com/NickMcCoy/AHK-Console-Class