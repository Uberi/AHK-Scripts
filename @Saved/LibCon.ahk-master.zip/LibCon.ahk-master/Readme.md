LibCon
================================================
AutoHotkey Library For Console Support
------------------------------------------------
The main goal of this library is to maintain simplicity, so that the common AutoHotkey user may use it and integrate it easily. ;)  
I know that this is probably considered far from complete, but just to get things started, here it is!  
See the [Documentation here.](LibCon_docs.md) See some [Examples here.](Examples.md) View the [Discussion here.](http://ahkscript.org/boards/viewtopic.php?t=17)  

LibCon is proudly under the [MIT License.](License.md)
  
------------------------------------------------
![Preview](preview.png "Preview")
  
------------------------------------------------
[Contact Me](mailto:joedf@users.sourceforge.net) for Requests, Comments, Contributions, etc.
